import {StyleSheet, Dimensions, TouchableOpacity, Text} from 'react-native';
const ScreenWidth = Dimensions.get('screen').width;
const TextButton = ({
  style = {},
  text = '',
  textStyle = {},
  onPress = () => {},
}) => {
  return (
    <TouchableOpacity style={[styles.container, style]} onPress={onPress}>
      <Text style={[styles.text, textStyle]}>{text}</Text>
    </TouchableOpacity>
  );
};
const styles = StyleSheet.create({
  container: {
    width: ScreenWidth / 1.8,
    backgroundColor: '#55a2ff',
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 14,
  },
  text: {
    fontWeight: 'bold',
    fontSize: 16,
    color: '#fff',
  },
});
export default TextButton;
