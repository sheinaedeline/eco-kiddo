import {StyleSheet} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Card from '../../components/Card';
import Header from '../../components/Header';
import IconTextButton from '../../components/IconTextButton';
import TextButton from '../../components/TextButton';

const SettingPage = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <Header navigation={navigation} title="Setting" />
      <Card style={{flex: null, marginHorizontal: 10, marginTop: 30}}>
        <IconTextButton
          icon={require('../../assets/download-9.png')}
          text="Notifications"
          onPress={() => navigation.navigate('NotifiactionSettingPage')}
        />
        <IconTextButton
          icon={require('../../assets/download-19.png')}
          text="Payment Methods"
          onPress={() => navigation.navigate('PaymentPage')}
        />
        <IconTextButton
          icon={require('../../assets/download-17.png')}
          text="Theme"
        />
        <IconTextButton
          icon={require('../../assets/download-3.png')}
          text="Switch Account"
        />
        <IconTextButton
          icon={require('../../assets/download-2.png')}
          text="Add New Account"
        />
        <IconTextButton
          icon={require('../../assets/download-8.png')}
          text="Help"
          onPress={() => navigation.navigate('HelpPage')}
        />
      </Card>
      <TextButton
        text="Back to Profile"
        style={{marginTop: 30, alignSelf: 'center'}}
        onPress={() => navigation.goBack()}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

export default SettingPage;
