import {View, Image, StyleSheet, Text, TouchableOpacity} from 'react-native';

const AddButton = ({
  icon = require('../../assets/download-23.png'),
  text = '',
  onPress = () => {},
}) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <Image source={icon} style={styles.icon} resizeMode={'contain'} />
        <Text style={styles.text}>{text}</Text>
      </View>
      <Text style={styles.addText}>Add</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 40,
    marginVertical: 2,
  },
  icon: {
    width: 24,
    height: 24,
  },
  text: {
    fontSize: 14,
    marginLeft: 16,
  },
  addText: {
    fontSize: 14,
    marginRight: 10,
    textDecorationLine: 'underline',
  },
});

export default AddButton;
