import {StyleSheet, View, Image, Text} from 'react-native';

const IconText = ({icon = null, title = '', titleStyle = {}}) => {
  return (
    <View style={styles.item}>
      <Image source={icon} style={styles.icon} resizeMode={'contain'} />
      <Text style={[styles.contentText, titleStyle]}>{title}</Text>
    </View>
  );
};
const styles = StyleSheet.create({
  icon: {
    width: 24,
    height: 24,
  },
  contentText: {
    fontSize: 14,
    marginLeft: 10,
    marginTop: 4,
  },
  item: {
    flexDirection: 'row',
    marginRight: 20,
    marginTop: 16,
  },
});
export default IconText;
