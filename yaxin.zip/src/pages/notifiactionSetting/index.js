import {StyleSheet, Text} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Card from '../../components/Card';
import Header from '../../components/Header';
import IconSwitchButton from '../../components/IconSwitchButton';

const NotifiactionSettingPage = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <Header navigation={navigation} title="Notifications" />
      <Text style={styles.title}>Push Notifications</Text>
      <Card style={{flex: null, marginHorizontal: 10}}>
        <IconSwitchButton
          icon={require('../../assets/download.png')}
          title="Messages"
          text="From firends"
          style={{marginBottom: 12}}
        />
        <IconSwitchButton
          icon={require('../../assets/download-14.png')}
          title="Account Activity"
          text="Changes made to your account"
          style={{marginBottom: 12}}
        />
        <IconSwitchButton
          icon={require('../../assets/download-13.png')}
          title="Product Announcements"
          text="Feature updates and more"
          style={{marginBottom: 12}}
        />
        <IconSwitchButton
          icon={require('../../assets/download-6.png')}
          title="Recommendations"
          text="Ideas and price alerts"
        />
      </Card>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 16,
    fontWeight: '500',
    color: '#2c2c2c',
    marginLeft: 20,
    marginBottom: 14,
    marginTop: 30,
  },
});

export default NotifiactionSettingPage;
