import {useState} from 'react';
import {
  View,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  Switch,
} from 'react-native';

const IconSwitchButton = ({
  icon = require('../../assets/download-23.png'),
  title = '',
  text = '',
  style = {},
}) => {
  const [disable, setDisable] = useState(false);
  return (
    <View style={[styles.container, style]}>
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <Image source={icon} style={styles.icon} resizeMode={'contain'} />
        <View style={{marginLeft: 16}}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.text}>{text}</Text>
        </View>
      </View>
      <Switch
        value={disable}
        onChange={() => {
          setDisable(!disable);
        }}
        // ios_backgroundColor={'#ffffff'}
        // trackColor={{false: '#000000', true: '#000000'}}
        // thumbColor={disable ? '#ffffff' : '#000000'}
        // style={{borderColor: '#000000', borderWidth: 1, borderRadius: 16}}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 40,
    marginVertical: 2,
  },
  icon: {
    width: 24,
    height: 24,
  },
  title: {
    fontSize: 14,
    color: '#000',
  },
  text: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  nextIcon: {
    width: 14,
    height: 14,
  },
});

export default IconSwitchButton;
