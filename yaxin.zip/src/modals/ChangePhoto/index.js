import {forwardRef, useImperativeHandle, useState} from 'react';
import {
  Modal,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Line from '../../components/Line';

const ChangePhoto = ({}, ref) => {
  const [visible, setVisible] = useState(false);
  useImperativeHandle(ref, () => ({
    modalVisible: modalVisible,
  }));

  const modalVisible = () => {
    setVisible(!visible);
  };

  const ButtonList = () => {
    return (
      <>
        <View style={{width: '90%', borderRadius: 10, backgroundColor: '#fff'}}>
          <TouchableOpacity style={styles.buttonItem}>
            <Text>Photo Library</Text>
          </TouchableOpacity>
          <Line
            style={{
              marginHorizontal: 30,
              height: 0.5,
              backgroundColor: '#9c9c9c',
            }}
          />
          <TouchableOpacity style={styles.buttonItem}>
            <Text>Take Photo</Text>
          </TouchableOpacity>
        </View>
      </>
    );
  };

  const CancleButton = () => {
    return (
      <View
        style={{
          width: '90%',
          borderRadius: 10,
          backgroundColor: '#fff',
          marginTop: 20,
        }}>
        <TouchableOpacity style={styles.buttonItem} onPress={modalVisible}>
          <Text>Cancle</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <Modal visible={visible} transparent>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(0,0,0,0.6)',
          flexDirection: 'row',
        }}
        disabled={true}
        onPress={modalVisible}>
        <SafeAreaView
          style={{justifyContent: 'flex-end', flex: 1, alignItems: 'center'}}>
          {ButtonList()}
          {CancleButton()}
        </SafeAreaView>
      </TouchableOpacity>
    </Modal>
  );
};

const styles = StyleSheet.create({
  buttonItem: {
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default forwardRef(ChangePhoto);
