import {View, Text, TouchableOpacity, Image, StyleSheet} from 'react-native';

const Header = ({navigation, title = ''}) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.touchContainer}>
        <TouchableOpacity
          style={styles.back}
          onPress={() => navigation.goBack()}>
          <Image
            source={require('../../assets/Back.png')}
            style={{width: 32, height: 32}}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  touchContainer: {
    flexDirection: 'row',
    position: 'absolute',
    alignItems: 'center',
    height: 50,
    width: '100%',
  },
  back: {
    marginLeft: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000',
  },
});

export default Header;
