import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Header from '../../components/Header';

const NotificationsPage = ({navigation}) => {
  const data = [1, 1, 1, 1, 1, 1, 1, 1, 1];
  const TitleHeader = () => {
    return (
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          marginTop: 20,
          paddingBottom: 10,
        }}>
        <Text style={{fontWeight: 'bold', fontSize: 26, marginLeft: 30}}>
          Notifications
        </Text>
        <TouchableOpacity style={styles.markReadButton}>
          <Text style={{color: '#55a2ff', fontSize: 12}}>Mark all as Read</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const renderItem = ({item, index}) => {
    return (
      <View
        style={[
          {
            flexDirection: 'row',
            paddingVertical: 30,
            paddingHorizontal: 20,
            flex: 1,
          },
          index + 1 === data.length
            ? {}
            : {borderBottomColor: '#dadee1', borderBottomWidth: 0.5},
        ]}>
        <Image
          source={require('../../assets/download-7.png')}
          style={{width: 40, height: 40}}
        />
        <View style={{flex: 1, marginLeft: 20}}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text style={{fontWeight: 'bold', fontSize: 16}}>Location</Text>
            <Text style={{fontSize: 12}}>October 2</Text>
          </View>
          <Text style={{fontSize: 12, marginTop: 4}}>
            New Local drop off location added
          </Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <Header navigation={navigation} />
      {TitleHeader()}
      <FlatList style={{flex: 1}} data={data} renderItem={renderItem} />
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  markReadButton: {
    borderColor: '#55a2ff',
    borderWidth: 1,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 6,
    marginRight: 20,
  },
});
export default NotificationsPage;
