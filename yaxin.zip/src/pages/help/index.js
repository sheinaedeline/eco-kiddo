import {View, StyleSheet, Image, Text} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Header from '../../components/Header';

const HelpPage = ({navigation}) => {
  const InformationUs = (
    icon = require('../../assets/download-16.png'),
    title = '',
    content = '',
  ) => {
    return (
      <View style={styles.informationContainer}>
        <View style={styles.iconContainer}>
          <Image source={icon} style={styles.icon} />
        </View>
        <View style={styles.content}>
          <Text style={styles.contentTitle}>{title}</Text>
          <Text style={styles.contentText}>{content}</Text>
        </View>
      </View>
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <Header navigation={navigation} title="Help" />
      <Image
        source={require('../../assets/help.png')}
        style={{width: 300, height: 225, alignSelf: 'center'}}
      />
      <Text
        style={{
          fontWeight: 'bold',
          textAlign: 'center',
          lineHeight: 24,
          alignSelf: 'center',
        }}>
        {`We are here to help so please get \nin touch with us.`}
      </Text>
      <View>
        {InformationUs(
          require('../../assets/download-16.png'),
          'Contact us',
          '+61 0112345678',
        )}
        {InformationUs(
          require('../../assets/download-21.png'),
          'E-mail',
          'hello@ecokiddo.com',
        )}
        {InformationUs(
          require('../../assets/download.png'),
          'Contact live chat',
          'we are ready to answer you',
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    // alignItems: 'center',
  },
  informationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 40,
  },
  iconContainer: {
    backgroundColor: '#e9f3ff',
    width: 46,
    height: 46,
    borderRadius: 23,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 50,
  },
  icon: {
    width: 26,
    height: 26,
  },
  content: {
    marginLeft: 20,
  },
  contentTitle: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 4,
  },
  contentText: {
    color: '#999999',
    fontSize: 14,
  },
});

export default HelpPage;
