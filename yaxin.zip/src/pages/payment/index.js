import {StyleSheet} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import AddButton from '../../components/AddButton';
import Card from '../../components/Card';
import Header from '../../components/Header';

const PaymentPage = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <Header navigation={navigation} title="Payment Methods" />
      <Card style={{flex: null, marginHorizontal: 10, marginTop: 30}}>
        <AddButton
          icon={require('../../assets/download-19.png')}
          text="Payment Methods"
          onPress={() => {}}
        />
      </Card>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

export default PaymentPage;
