import {TouchableOpacity, View, Text} from 'react-native';

const HomePage = props => {
  console.log(props);
  const {navigation} = props;
  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <TouchableOpacity
        onPress={() => {
          navigation.navigate('ProfilePage');
        }}>
        <Text>ProfilePage</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => {
          navigation.navigate('NotificationsPage');
        }}>
        <Text>NotificationsPage</Text>
      </TouchableOpacity>
    </View>
  );
};

export default HomePage;
