import {StyleSheet, View} from 'react-native';

const Card = ({children, style}) => {
  return <View style={[styles.container, style]}>{children}</View>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    shadowColor: '#999999',
    shadowOffset: {width: 0, height: 3},
    shadowOpacity: 0.7,
    shadowRadius: 5,
    elevation: 4,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    paddingBottom: 20,
    paddingTop: 14,
    paddingHorizontal: 20,
  },
});

export default Card;
