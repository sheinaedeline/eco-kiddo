import {StyleSheet, View, Text, Image, ScrollView, Switch} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Card from '../../components/Card';
import Header from '../../components/Header';
import IconText from '../../components/IconText';
import IconTextButton from '../../components/IconTextButton';
import TextButton from '../../components/TextButton';
import ProfileHeader from './component/ProfileHeader';

const ProfilePage = ({navigation}) => {
  const Accessibility = () => {
    return (
      <View style={[styles.infoContainer, {marginTop: 20}]}>
        <Text style={styles.title}>Accessibility</Text>
        <Card>
          <View style={styles.item}>
            <Image
              source={require('../../assets/download-23.png')}
              style={styles.icon}
              resizeMode={'contain'}
            />
            <View style={{marginTop: -6}}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                <Text style={styles.contentText}>Drak Mode</Text>
                <Switch />
              </View>
              <Text style={[styles.contentText, styles.greyText]}>
                Change UX to users preferred colour mode
              </Text>
            </View>
          </View>
        </Card>
      </View>
    );
  };

  const About = () => {
    return (
      <View style={[styles.infoContainer, {marginTop: 20}]}>
        <Text style={styles.title}>About</Text>
        <Card>
          <IconTextButton
            icon={require('../../assets/download-22.png')}
            text="Contact"
          />
          <IconTextButton
            icon={require('../../assets/download-4.png')}
            text="Settings"
            onPress={() => navigation.navigate('SettingPage')}
          />
          <IconTextButton
            icon={require('../../assets/download-25.png')}
            text="Privacy"
          />
          <IconTextButton
            icon={require('../../assets/download-18.png')}
            text="Terms of service"
          />
        </Card>
      </View>
    );
  };

  const EditLogOutButton = () => {
    return (
      <View
        style={{
          alignSelf: 'center',
        }}>
        <TextButton text="Edit Profile" style={{marginTop: 30}} />
        <TextButton
          text="Log Out"
          style={{
            backgroundColor: '#fff',
            borderWidth: 2,
            borderColor: '#55a2ff',
            marginTop: 20,
          }}
          textStyle={{
            color: '#55a2ff',
          }}
        />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <Header navigation={navigation} title="Profile" />
      <ScrollView style={{flex: 1}} contentContainerStyle={{paddingBottom: 20}}>
        <ProfileHeader />
        <View style={[styles.infoContainer, {marginTop: 30}]}>
          <Text style={styles.title}>Basic profile</Text>
          <Card>
            <IconText
              icon={require('../../assets/download-11.png')}
              title="Michael Jordan"
            />
            <IconText
              icon={require('../../assets/download-1.png')}
              title="https://www.baidu.com/"
            />
            <IconText
              icon={require('../../assets/download-24.png')}
              title="Here is a little bit about me. and so it goes on and on and on"
            />
          </Card>
        </View>
        <View style={[styles.infoContainer, {marginTop: 20}]}>
          <Text style={styles.title}>Private Information</Text>
          <Card>
            <IconText
              icon={require('../../assets/download-20.png')}
              title="michael@Jordan.com"
            />
            <IconText
              icon={require('../../assets/download-15.png')}
              title="+61 0510 123 456"
            />
            <IconText
              icon={require('../../assets/download-5.png')}
              title="male"
            />
          </Card>
        </View>
        <View style={[styles.infoContainer, {marginTop: 20}]}>
          <Text style={styles.title}>Change Password</Text>
          <Card>
            <IconText
              icon={require('../../assets/download-26.png')}
              title="Enter New Password"
              titleStyle={styles.greyText}
            />
            <IconText
              icon={require('../../assets/download-26.png')}
              title="Confirm New Password"
              titleStyle={styles.greyText}
            />
          </Card>
        </View>
        {Accessibility()}
        {About()}
        {EditLogOutButton()}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  infoContainer: {
    flex: 1,
    marginHorizontal: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2c2c2c',
    marginLeft: 6,
    marginBottom: 14,
  },
  icon: {
    width: 24,
    height: 24,
  },
  contentText: {
    fontSize: 14,
    marginLeft: 10,
    marginTop: 4,
  },
  greyText: {
    color: '#b0aeaf',
  },
  item: {
    flexDirection: 'row',
    marginRight: 20,
    marginTop: 16,
  },
});

export default ProfilePage;
