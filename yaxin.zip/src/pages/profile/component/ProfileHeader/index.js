import {useRef} from 'react';
import {Image, View, Text, TouchableOpacity} from 'react-native';
import ChangePhoto from '../../../../modals/ChangePhoto';

const ProfileHeader = () => {
  const changePhotoRef = useRef(null);
  const changePhoto = () => {
    changePhotoRef.current?.modalVisible();
  };
  return (
    <View
      style={{alignItems: 'center', justifyContent: 'center', marginTop: 10}}>
      <TouchableOpacity onPress={changePhoto}>
        <Image
          source={require('../../../../assets/headerDefault.png')}
          style={{width: 128, height: 128}}
          resizeMode={'contain'}
        />
      </TouchableOpacity>
      <Text style={{fontSize: 22, fontWeight: 'bold', marginTop: 5}}>
        Michael
      </Text>
      <Text
        style={{
          fontSize: 12,
          marginTop: 5,
          fontWeight: 'bold',
          color: '#515151',
        }}>
        michael@jordan.com
      </Text>
      <ChangePhoto ref={changePhotoRef} />
    </View>
  );
};

export default ProfileHeader;
