import {View} from 'react-native';

const Line = ({style = {}}) => {
  return <View style={[{height: 1, backgroundColor: '#000'}, style]} />;
};

export default Line;
